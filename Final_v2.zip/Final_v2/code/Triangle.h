#ifndef TRIANGLE_H
#define TRIANGLE_H

#endif // TRIANGLE_H
